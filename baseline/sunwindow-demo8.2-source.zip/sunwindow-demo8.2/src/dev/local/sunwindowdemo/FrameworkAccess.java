package dev.local.sunwindowdemo;

import android.content.res.Configuration;
import android.graphics.*;
import android.view.SurfaceControl;
import java.lang.reflect.*;
import java.util.*;

/** Reflect exact target signatures; never invoke an arbitrary same-name overload. */
final class FrameworkAccess {
    final Class<?> task, wc, activity, tda, dc;
    final int invisibleFlag;
    final Method systemReady, prepare, changed, freeform, lookup, focused, recentVisible, systemBars;
    final Method requestTransition;
    private final Map<String, Method> methods = new HashMap<>();
    private final Map<String, Field> fields = new HashMap<>();
    FrameworkAccess(ClassLoader loader) throws Exception {
        task = Class.forName("com.android.server.wm.Task", false, loader);
        wc = Class.forName("com.android.server.wm.WindowContainer", false, loader);
        activity = Class.forName("com.android.server.wm.ActivityRecord", false, loader);
        tda = Class.forName("com.android.server.wm.TaskDisplayArea", false, loader);
        dc = Class.forName("com.android.server.wm.DisplayContent", false, loader);
        Class<?> wms = Class.forName("com.android.server.wm.WindowManagerService", false, loader);
        Class<?> root = Class.forName("com.android.server.wm.RootWindowContainer", false, loader);
        systemReady = method(wms, "systemReady");
        prepare = method(task, "prepareSurfaces");
        changed = method(task, "onConfigurationChanged", Configuration.class);
        freeform = method(task, "computeFreeformBounds", Rect.class, Configuration.class);
        lookup = method(root, "anyTaskForId", int.class, int.class);
        focused = method(root, "getTopDisplayFocusedLeafTask");
        for (Method m : new Method[]{systemReady, prepare, changed, freeform})
            if (m.getReturnType() != void.class) throw new NoSuchMethodException(m.toString());
        method(task, "setWindowingMode", int.class);
        method(task, "setBounds", Rect.class);
        method(task, "setAlwaysOnTop", boolean.class);
        method(task, "isRootTask"); method(task, "isLeafTask");
        method(task, "supportsFreeformInDisplayArea", tda);
        method(tda, "isValidWindowingMode", int.class, activity, task);
        method(wms, "requestTraversal");
        method(wc, "getRelativePosition", Point.class);
        method(wc, "getPendingTransaction"); method(wc, "getBounds");
        method(wc, "getRelativeDisplayRotation");
        method(field(wc,"mTransitionController").getType(),"setNoAnimation",wc);
        method(wc, "isAttached"); method(wc, "getDisplayContent");
        method(dc, "getStableRect", Rect.class);
        method(field(wc,"mTransitionController").getType(),"setNoAnimation",wc);
        Class<?> insetsController=method(dc,"getInsetsStateController").getReturnType();
        Class<?> insetsState=method(insetsController,"getRawInsetsState").getReturnType();
        method(insetsState,"calculateInsets",Rect.class,Rect.class,int.class,boolean.class);
        field(dc, "mDisplayId");
        method(wc,"forAllTasks",java.util.function.Consumer.class);
        method(task,"moveToFront",String.class);
        method(task,"moveTaskToBack",task);
        Class<?> transition=Class.forName("com.android.server.wm.Transition",false,loader);
        method(transition,"collect",wc);method(transition,"setNoAnimation",wc);
        method(transition,"addFlag",int.class);field(transition,"mType");
        method(transition,"getFlags");
        requestTransition=method(field(wc,"mTransitionController").getType(),"requestStartTransition",
            transition,task,Class.forName("android.window.RemoteTransition",false,loader),List.class);
        invisibleFlag=field(android.view.WindowManager.class,"TRANSIT_FLAG_INVISIBLE").getInt(null);
        if(invisibleFlag==0)throw new IllegalStateException("invalid native no-animation flag");
        method(task,"moveTaskToBackInner",task,transition);
        method(task,"updateSurfaceSize",SurfaceControl.Transaction.class);
        method(task,"isVisibleRequested");
        method(android.app.ActivityOptions.class,"setLaunchTaskId",int.class);
        Class<?> snapshot=field(wms,"mTaskSnapshotController").getType();method(snapshot,"recordSnapshot",task);
        method(task,"setFocusable",boolean.class);method(task,"isFocusable");
        method(task,"setForceTranslucent",boolean.class);method(task,"isForceTranslucent");
        method(task,"isForceOpaque");
        method(android.app.ActivityOptions.class,"setAvoidMoveToFront");
        method(root,"resumeFocusedTasksTopActivities");method(root,"ensureActivitiesVisible");
        field(task,"mLastSurfaceSize");
        field(task,"mLastTimeMoved");
        for (String name : new String[]{"getBaseIntent", "getParent", "getDisplayArea", "getActivityType", "getWindowingMode",
                "getConfiguration", "getRequestedOverrideConfiguration", "getBounds", "isAlwaysOnTop",
                "isOverrideBoundsAllowed", "isOverrideWindowingModeAllowed"}) method(task, name);
        method(task, "onRequestedOverrideConfigurationChanged", Configuration.class);
        Class<?> winConfig = Class.forName("android.app.WindowConfiguration", false, loader);
        method(winConfig, "setAlwaysOnTop", int.class); method(winConfig, "getWindowingMode"); method(winConfig, "getBounds");
        field(winConfig, "mAlwaysOnTop"); field(Configuration.class, "windowConfiguration");
        method(SurfaceControl.Transaction.class, "setScale", SurfaceControl.class, float.class, float.class);
        method(SurfaceControl.Transaction.class, "setPosition", SurfaceControl.class, float.class, float.class);
        method(SurfaceControl.Transaction.class,"setWindowCrop",SurfaceControl.class,int.class,int.class);
        method(SurfaceControl.Transaction.class,"setCornerRadius",SurfaceControl.class,float.class);
        for (String name : new String[]{"mContext", "mRoot", "mGlobalLock", "mAtmService"}) field(wms, name);
        for (String name : new String[]{"mTaskId", "mUserId", "realActivity"}) field(task, name);
        for (String name : new String[]{"mSurfaceControl", "mSurfaceAnimator", "mTransitionController"}) field(wc, name);
        method(field(wc, "mSurfaceAnimator").getType(), "hasLeash");
        method(field(wc, "mTransitionController").getType(), "inTransition", wc);
        TaskDecoration.preflight(this);
        recentVisible=method(Class.forName("com.android.server.wm.RecentTasks",false,loader),"isVisibleRecentTask",task);
        Class<?> win=Class.forName("com.android.server.wm.WindowState",false,loader);
        Class<?> insets=Class.forName("com.android.server.wm.InsetsPolicy",false,loader);
        systemBars=method(insets,"updateSystemBars",win,int.class,int.class,boolean.class);
        field(insets,"mDisplayContent");method(win,"getTask");method(dc,"getDisplayPolicy");
        method(win,"getFrame");method(field(win,"mLastReportedConfiguration").getType(),"getMergedConfiguration");
        Class<?> policy=Class.forName("com.android.server.wm.DisplayPolicy",false,loader);
        field(policy,"mTopFullscreenOpaqueWindowState");
        Class<?> atm = field(wms, "mAtmService").getType();
        method(field(atm,"mTaskChangeNotificationController").getType(),"notifyTaskStackChanged");
        method(atm,"deferWindowLayout");method(atm,"continueWindowLayout");
        field(atm, "mSupportsMultiWindow"); field(atm, "mSupportsFreeformWindowManagement");
    }
    synchronized Method method(Class<?> owner, String name, Class<?>... args) throws Exception {
        String key = owner.getName() + "#" + name + Arrays.toString(args);
        Method found = methods.get(key);
        if (found != null) return found;
        for (Class<?> type = owner; type != null; type = type.getSuperclass()) {
            try {
                found = type.getDeclaredMethod(name, args); found.setAccessible(true);
                methods.put(key, found); return found;
            } catch (NoSuchMethodException ignored) { }
        }
        throw new NoSuchMethodException(key);
    }
    synchronized Field field(Class<?> owner, String name) throws Exception {
        String key = owner.getName() + "#" + name;
        Field found = fields.get(key);
        if (found != null) return found;
        for (Class<?> type = owner; type != null; type = type.getSuperclass()) {
            try {
                found = type.getDeclaredField(name); found.setAccessible(true);
                fields.put(key, found); return found;
            } catch (NoSuchFieldException ignored) { }
        }
        throw new NoSuchFieldException(key);
    }
    Object field(Object owner, String name) throws Exception { return field(owner.getClass(), name).get(owner); }
    Object call(Object owner, String name) throws Exception { return method(owner.getClass(), name).invoke(owner); }
    Object call(Object owner, String name, Class<?>[] types, Object... args) throws Exception {
        return method(owner.getClass(), name, types).invoke(owner, args);
    }
    boolean bool(Object owner, String name) throws Exception { return (Boolean) call(owner, name); }
    int integer(Object owner, String name) throws Exception { return (Integer) call(owner, name); }
    Configuration config(Object owner, boolean requested) throws Exception {
        return (Configuration) call(owner, requested ? "getRequestedOverrideConfiguration" : "getConfiguration");
    }
    Object windowConfig(Object owner, boolean requested) throws Exception { return field(config(owner, requested), "windowConfiguration"); }
    void transform(Object target, float scale, float x, float y) throws Exception {
        Object surface = field(target, "mSurfaceControl");
        if (!(surface instanceof SurfaceControl) || !((SurfaceControl) surface).isValid())
            throw new IllegalStateException("surface unavailable");
        Object transaction = transaction(target);
        call(transaction, "setScale", new Class<?>[]{SurfaceControl.class, float.class, float.class}, surface, scale, scale);
        call(transaction, "setPosition", new Class<?>[]{SurfaceControl.class, float.class, float.class}, surface, x, y);
    }
    private SurfaceControl.Transaction renderTransaction,frameTransaction;
    boolean inFrame(){return frameTransaction!=null;}
    void beginFrame(){
        if(frameTransaction!=null)throw new IllegalStateException("nested surface frame");
        if(renderTransaction==null)renderTransaction=new SurfaceControl.Transaction();
        frameTransaction=renderTransaction;
    }
    Object transaction(Object task) throws Exception {return frameTransaction!=null?frameTransaction:call(task,"getPendingTransaction");}
    void endFrame(boolean commit){
        SurfaceControl.Transaction t=frameTransaction;frameTransaction=null;
        if(t==null)return;
        if(commit){
            try{t.apply();}catch(RuntimeException e){t.close();renderTransaction=null;throw e;}
        }else{t.close();renderTransaction=null;}
    }
    boolean animating(Object target) throws Exception {
        return bool(field(target, "mSurfaceAnimator"), "hasLeash")
            || (Boolean) call(field(target, "mTransitionController"), "inTransition", new Class<?>[]{wc}, target);
    }
    void opacity(Object target,float alpha) throws Exception {
        call(transaction(target),"setAlpha",new Class<?>[]{SurfaceControl.class,float.class},field(target,"mSurfaceControl"),alpha);
    }
    void style(Object target,int width,int height,float radius) throws Exception {
        Object surface=field(target,"mSurfaceControl"),transaction=transaction(target);
        call(transaction,"setWindowCrop",new Class<?>[]{SurfaceControl.class,int.class,int.class},surface,width,height);
        call(transaction,"setCornerRadius",new Class<?>[]{SurfaceControl.class,float.class},surface,radius);
    }
    static String reason(Throwable e) {
        while (e instanceof InvocationTargetException && e.getCause() != null) e = e.getCause();
        String message = e.getMessage();
        return e.getClass().getSimpleName() + (message == null ? "" : ": " + message);
    }
}
