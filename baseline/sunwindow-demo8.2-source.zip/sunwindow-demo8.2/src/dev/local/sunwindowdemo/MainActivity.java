package dev.local.sunwindowdemo;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.Toast;

public final class MainActivity extends DemoActivity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private String recoverPackage, recoverToken, recoverComponent;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        text("SunOS 小窗 · Demo8.2", 25);
        text("0.8.2-test1 · 普通窗 / 迷你窗 / 全屏\n每轮 3 分钟，到期关闭悬浮并恢复任务。", 15);
        button("检查系统框架与恢复状态", () -> {
            backendSeen = false; status.setText("正在等待系统后端……"); Wire.send(this, "STATUS");
            ui.postDelayed(this::missingBackend, 2000);
        });
        button("① 打开内置触摸 / 键盘诊断页", () -> {
            TaskTools.openDiagnostic(this);
        });
        button("角落手势与快捷应用设置",()->startActivity(new Intent(this,SettingsActivity.class)));
        button("开启 Demo8.2 无障碍手势与窗口控制",()->startActivity(new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        button("② 用 Chrome 测试（复用任务）", this::chrome);
        button("恢复原窗口并结束本轮测试", () -> Wire.send(this, "RESTORE"));
        button("打开待恢复任务（仅恢复记录存在时）", this::reopen);
        button("允许显示恢复通知（可选）", () -> {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5);
            else Toast.makeText(this, "通知权限已开启", Toast.LENGTH_SHORT).show();
        });
        text("LSPosed 勾选 system、系统界面与 Pixel 启动器并重启，再开启 Demo8.2 无障碍服务。请关闭旧 Demo 的角落手势。\n当前应用：侧边返回长滑，震动后松手进入小窗。\n普通窗：白条向内推缩成迷你窗，向外拉到全屏；点外部关闭。\n迷你窗：点击还原、双击全屏、拖入顶部关闭区松手关闭。", 14);
        status = text("等待后端状态……", 13); status.setTextIsSelectable(true);
        if ("recover".equals(getIntent().getAction())) Wire.send(this, "RESTORE");
        ui.postDelayed(this::missingBackend, 2000);
    }
    @Override void onBackendResult(Intent i) {
        recoverPackage = i.getStringExtra("recoverPackage"); recoverToken = i.getStringExtra("recoverToken");
        recoverComponent = i.getStringExtra("recoverComponent");
        if("idle".equals(i.getStringExtra("state"))&&!i.getBooleanExtra("hasJournal",true))TaskTools.trimIdle(this);
        if("ACTIVE".equals(i.getStringExtra("event"))&&isTaskRoot())finishAndRemoveTask();
    }
    private void reopen() {
        ComponentName component = recoverComponent == null ? null : ComponentName.unflattenFromString(recoverComponent);
        if (!Wire.allowedPackage(recoverPackage) || !Wire.validToken(recoverToken) || component == null
            || !recoverPackage.equals(component.getPackageName())) {
            Toast.makeText(this, "没有可重新打开的恢复记录，先点恢复按钮检查", Toast.LENGTH_LONG).show(); return;
        }
        Intent launch=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if(Wire.PKG.equals(recoverPackage))launch.setIdentifier(recoverToken);
        startActivity(launch);
        ui.postDelayed(() -> Wire.send(this, "RESTORE"), 1400);
    }
    private void missingBackend() {
        if (!backendSeen && !isFinishing()) status.setText("尚未收到系统后端回应。\n确认 Demo8.2 已激活，勾选 system 后重启。日志标签 SunWindowDemo5。");
    }
    private void chrome() {
        if(!backendCompatible||!CornerService.connected){Toast.makeText(this,"请先完成后端预检并开启 Demo8.2 无障碍服务",1).show();return;}
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.android.chrome");
        if (launch == null || launch.getComponent() == null) {
            Toast.makeText(this, "没有找到 Chrome，先测诊断页", Toast.LENGTH_LONG).show(); return;
        }
        Wire.send(this,"OPEN","com.android.chrome",-1,Wire.token(),false);
    }
    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i); setIntent(i);
        if ("recover".equals(i.getAction())) Wire.send(this, "RESTORE");
    }
    @Override public void onDestroy() { ui.removeCallbacksAndMessages(null); super.onDestroy(); }
}
