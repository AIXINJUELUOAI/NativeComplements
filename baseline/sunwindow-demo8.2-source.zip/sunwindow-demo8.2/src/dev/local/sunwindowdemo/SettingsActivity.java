package dev.local.sunwindowdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

public final class SettingsActivity extends Activity {
    private Config config;
    private LinearLayout body;
    private List<AppCatalog.App> all = List.of();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state); config=new Config(this);
        new Thread(() -> {
            List<AppCatalog.App> loaded=AppCatalog.load(this);
            runOnUiThread(() -> { if(!isDestroyed()) {all=loaded; render();} });
        },"corner-app-catalog").start();
    }
    @Override public void onResume() { super.onResume(); render(); }
    private void text(String s, int size) { TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(0,14,0,10);body.addView(t); }
    private void button(String s,Runnable action) { Button b=new Button(this);b.setText(s);b.setOnClickListener(v->action.run());body.addView(b); }
    private void toggle(String label,String key,boolean value) {
        Switch s=new Switch(this);s.setText(label);s.setChecked(value);s.setPadding(0,18,0,18);
        s.setOnCheckedChangeListener((v,on)->config.prefs.edit().putBoolean(key,on).apply());body.addView(s);
    }
    private void slider(String label,String key,int value,int min,int max,String unit) {
        TextView t=new TextView(this);t.setText(label+"："+value+unit);t.setPadding(0,18,0,0);body.addView(t);
        SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(value-min);body.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean user){t.setText(label+"："+(min+p)+unit);}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){config.prefs.edit().putInt(key,min+b.getProgress()).apply();}
        });
    }
    private void render() {
        if(config==null) return;
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(1);
        int pad=(int)(20*getResources().getDisplayMetrics().density);body.setPadding(pad,pad,pad,pad);scroll.addView(body);
        scroll.setOnApplyWindowInsetsListener((v,insets)->{android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars());v.setPadding(bars.left,bars.top,bars.right,bars.bottom);return insets;});
        setContentView(scroll);
        text("角落启动 · Demo 8.2",24);
        text(CornerService.connected?"角落手势服务已连接":"请先开启角落手势无障碍服务",16);
        text("最近手势："+CornerService.lastTouch,14);
        text("LSPosed 需勾选 system（系统框架）、系统界面和 Pixel 启动器三个作用域，更新后正常重启。桌面只让出实际启用的角落热区，其余导航保持原样。",14);
        button("打开无障碍设置",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        text("快捷应用",20);
        List<String> selected=config.apps();
        text("已选择 "+selected.size()+" / 5，另有一个固定应用列表入口",14);
        button("选择快捷应用",this::selectApps);
        for(int index=0;index<selected.size();index++) {
            final int i=index;String pkg=selected.get(i);String label=pkg;
            for(AppCatalog.App a:all)if(a.pkg.equals(pkg)){label=a.label;break;}
            text((i+1)+". "+label,16);
            LinearLayout row=new LinearLayout(this);
            for(String action:new String[]{"上移","下移","移除"}) {
                Button b=new Button(this);b.setText(action);row.addView(b,new LinearLayout.LayoutParams(0,-2,1));
                b.setEnabled(!action.equals("上移")||i>0);if(action.equals("下移")&&i==selected.size()-1)b.setEnabled(false);
                b.setOnClickListener(v->{List<String> next=config.apps();if(i>=next.size())return;
                    if(action.equals("移除"))next.remove(i);else java.util.Collections.swap(next,i,action.equals("上移")?i-1:i+1);
                    config.apps(next);render();});
            }body.addView(row);
        }
        text("小窗与多任务",20);
        toggle("在多任务中隐藏小窗应用","hideRecents",config.hideRecents());
        text("关闭或切换小窗后继续隐藏；用户真正全屏打开并完成绘制后重新显示。",14);
        button("空白处关闭方式："+(config.doubleClose()?"双击":"单击"),()->new AlertDialog.Builder(this).setTitle("空白处关闭方式")
            .setSingleChoiceItems(new String[]{"单击","双击"},config.doubleClose()?1:0,(d,which)->{
                config.prefs.edit().putBoolean("doubleClose",which==1).apply();d.dismiss();render();}).setNegativeButton("取消",null).show());
        text("当前应用：从屏幕侧边向内长滑，震动后松手进入小窗；退回可恢复普通返回。顶部提示可关闭。普通窗缩为迷你窗后停在右上角。",14);
        text("手势与菜单",20);
        toggle("关闭顶部提示","hideTopHint",config.hideTopHint());
        text("开发者调试",18);toggle("显示触发热区","showHeat",config.showHeat());
        text("蓝框是实际接收起手的位置，按中变绿；橙色表示触摸被取消。箭头指向斜滑方向。定位完成后可以关闭显示。",14);
        slider("角落热区边长","heat",config.heat(),Config.HEAT_MIN,Config.HEAT_MAX," dp");
        slider("触发滑动距离","distance",config.distance(),24,100," dp");
        slider("滑动选中距离","selectionDistance",config.selectionDistance(),50,100,"%");
        text("按图标到扇形圆心的距离计算：90%在图标附近选中，100%需滑到图标中心。触发滑动距离只控制菜单展开。",14);
        slider("扇形半径","radius",config.radius(),120,260," dp");
        slider("图标直径","icon",config.icon(),32,56," dp");
        text("图标多或较大时，半径会自动增大以防重叠。应用列表圆固定排在最后，左右镜像。震动与动画使用固定默认值。",14);
        text("防误触",20);
        toggle("横屏时禁用","landscape",config.landscapeOff());
        toggle("键盘弹出时禁用","keyboard",config.keyboardOff());
        button("指定应用内禁用（"+config.blocked().size()+"）",this::selectBlocked);
        text("角落手势延伸到屏幕边缘；横屏小窗只避开摄像头区域，竖屏避开系统栏和刘海。空白处按所选单击或双击方式关闭；应用在根页面返回时退出小窗。截图工具栏显示时暂停小窗触摸覆盖。",14);
    }
    private void selectApps() {
        if(all.isEmpty()){Toast.makeText(this,"应用列表正在加载",0).show();return;}
        ArrayList<String> chosen=new ArrayList<>(config.apps());boolean[] checked=new boolean[all.size()];
        String[] labels=new String[all.size()];for(int i=0;i<all.size();i++){labels[i]=all.get(i).label;checked[i]=chosen.contains(all.get(i).pkg);}
        new AlertDialog.Builder(this).setTitle("最多选择五个应用").setMultiChoiceItems(labels,checked,(dialog,index,on)->{
            String pkg=all.get(index).pkg;
            if(on&&chosen.size()>=5){((AlertDialog)dialog).getListView().setItemChecked(index,false);Toast.makeText(this,"最多五个应用",0).show();}
            else if(on){if(!chosen.contains(pkg))chosen.add(pkg);}else chosen.remove(pkg);
        }).setPositiveButton("保存",(d,w)->{config.apps(chosen);render();}).setNegativeButton("取消",null).show();
    }
    private void selectBlocked() {
        if(all.isEmpty()){Toast.makeText(this,"应用列表正在加载",0).show();return;}
        Set<String> chosen=new HashSet<>(config.blocked());boolean[] checked=new boolean[all.size()];String[] labels=new String[all.size()];
        for(int i=0;i<all.size();i++){labels[i]=all.get(i).label;checked[i]=chosen.contains(all.get(i).pkg);}
        new AlertDialog.Builder(this).setTitle("这些应用内不触发角落菜单").setMultiChoiceItems(labels,checked,(d,i,on)->{if(on)chosen.add(all.get(i).pkg);else chosen.remove(all.get(i).pkg);})
            .setPositiveButton("保存",(d,w)->{config.prefs.edit().putStringSet("blocked",chosen).apply();render();}).setNegativeButton("取消",null).show();
    }
}
