"""Build using the installed JDK + Android SDK, without Gradle or phone access."""
import argparse
import pathlib
import subprocess
import zipfile
import hashlib
import os

p = argparse.ArgumentParser()
p.add_argument('--api', required=True, help='Official libxposed 101.0.1 classes.jar (compile-only)')
p.add_argument('--sdk', default=str(pathlib.Path(os.environ['LOCALAPPDATA']) / 'Android/Sdk'))
p.add_argument('--jdk', default=r'C:\Program Files\Android\Android Studio\jbr')
p.add_argument('--out', required=True)
p.add_argument('--keystore', help='Reuse an existing demo signing key for updates')
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parent
out = pathlib.Path(a.out).resolve()
out.mkdir(parents=True, exist_ok=True)
sdk, jdk = pathlib.Path(a.sdk), pathlib.Path(a.jdk)
tools = sdk / 'build-tools/36.1.0'
android = sdk / 'platforms/android-37.0/android.jar'
api = pathlib.Path(a.api).resolve()
classes = out / 'classes'
classes.mkdir(exist_ok=True)
def run(*args):
    subprocess.run([str(s) for s in args], check=True)
run(jdk/'bin/javac.exe', '-encoding', 'UTF-8', '--release', '17', '-classpath', str(android)+os.pathsep+str(api), '-d', classes,
    *root.glob('src/**/*.java'))
with zipfile.ZipFile(out/'code.jar', 'w') as z:
    for f in classes.rglob('*.class'): z.write(f, f.relative_to(classes).as_posix())
env_java = str(jdk/'bin/java.exe')
run(env_java, '-cp', tools/'lib/d8.jar', 'com.android.tools.r8.D8', '--min-api', '29', '--lib', android,
    '--classpath', api, '--output', out, out/'code.jar')
run(tools/'aapt2.exe', 'compile', '--dir', root/'res', '-o', out/'resources.zip')
run(tools/'aapt2.exe', 'link', '-I', android, '--manifest', root/'AndroidManifest.xml', '-o', out/'unsigned.apk', out/'resources.zip')
with zipfile.ZipFile(out/'unsigned.apk', 'a', zipfile.ZIP_DEFLATED) as z:
    z.write(out/'classes.dex', 'classes.dex')
    for f in (root/'META-INF').rglob('*'):
        if f.is_file():
            source = root/'NOTICE.md' if f == root/'META-INF/NOTICE' else f
            z.write(source, f.relative_to(root).as_posix())
run(tools/'zipalign.exe', '-f', '4', out/'unsigned.apk', out/'aligned.apk')
key = pathlib.Path(a.keystore).resolve() if a.keystore else out/'demo.keystore'
if not key.exists():
    run(jdk/'bin/keytool.exe', '-genkeypair', '-keystore', key, '-storepass', 'android', '-keypass', 'android',
        '-alias', 'demo', '-keyalg', 'RSA', '-keysize', '2048', '-validity', '3650', '-dname', 'CN=SunWindow Experimental Demo')
apk = out/'sunwindow-0.8.2-test1.apk'
run(env_java, '-jar', tools/'lib/apksigner.jar', 'sign', '--ks', key, '--ks-pass', 'pass:android',
    '--key-pass', 'pass:android', '--out', apk, out/'aligned.apk')
run(env_java, '-jar', tools/'lib/apksigner.jar', 'verify', '--verbose', apk)
print('SHA256', hashlib.sha256(apk.read_bytes()).hexdigest())
print(apk)
