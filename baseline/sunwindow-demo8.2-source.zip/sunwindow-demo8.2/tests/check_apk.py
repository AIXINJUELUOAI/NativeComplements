"""Verify the delivered archive, module metadata and actual DEX definitions."""
import argparse
import hashlib
import pathlib
import struct
import zipfile

p = argparse.ArgumentParser()
p.add_argument('apk')
a = p.parse_args()
apk = pathlib.Path(a.apk)
root = pathlib.Path(__file__).resolve().parents[1]
with zipfile.ZipFile(apk) as z:
    assert z.testzip() is None, 'ZIP CRC failure'
    assert set(z.read('META-INF/xposed/scope.list').decode().split()) == {'system','com.google.android.apps.nexuslauncher','com.android.systemui'}, 'require system_server, launcher and native-back UI scopes'
    assert set(z.read('META-INF/xposed/java_init.list').decode().split()) == {'dev.local.sunwindowdemo.SunWindowModule','dev.local.sunwindowdemo.LauncherGuard','dev.local.sunwindowdemo.BackBridge'}
    props = z.read('META-INF/xposed/module.prop').decode()
    assert 'minApiVersion=101' in props and 'staticScope=true' in props
    assert z.read('META-INF/LICENSE') == (root/'LICENSE').read_bytes()
    assert z.read('META-INF/NOTICE') == (root/'NOTICE.md').read_bytes()
    assert not any(n.endswith(('.jar', '.keystore')) for n in z.namelist())
    b = z.read('classes.dex')

u = lambda o: struct.unpack_from('<I', b, o)[0]
strings = []
for i in range(u(56)):
    offset = u(u(60)+4*i)
    while b[offset] & 128:
        offset += 1
    offset += 1
    strings.append(b[offset:b.index(0, offset)].decode('utf-8', errors='replace'))
types = [strings[u(u(68)+4*i)] for i in range(u(64))]
defined = [types[u(u(100)+32*i)] for i in range(u(96))]
assert 'Ldev/local/sunwindowdemo/SunWindowModule;' in defined
assert 'Ldev/local/sunwindowdemo/MainActivity;' in defined
assert 'Ldev/local/sunwindowdemo/DiagnosticActivity;' in defined
assert 'Ldev/local/sunwindowdemo/WindowHistory;' in defined
for marker in ['OPEN_PHASE package=', 'CLOSE_BACK_COMPLETE task=', 'HISTORY_FULLSCREEN_READY task=',
               'CLOSE_TRANSITION_INVISIBLE task=', 'VISIBILITY_END show=', 'hideTopHint', 'selectionDistance']:
    assert any(marker in value for value in strings), marker
assert all(n.startswith('Ldev/local/sunwindowdemo/') or n == 'Lcom/android/tools/r8/RecordTag;' for n in defined), defined
print(f'PASS APK: CRC, API-101 metadata, system-server and launcher scopes, license/notice, {len(defined)} DEX definitions; no bundled framework/API jar or signing key')
print('SHA256', hashlib.sha256(apk.read_bytes()).hexdigest())
