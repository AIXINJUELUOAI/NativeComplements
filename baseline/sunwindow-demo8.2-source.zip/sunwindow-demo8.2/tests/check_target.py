"""Match the adapter's signatures against real DEX declarations with inheritance.

Input is the offline DEX class_data inventory, not JADX method-reference guesses.
This verifies names/types only. It does not execute Android or validate hook timing.
"""
import argparse
import hashlib
import json
import pathlib

p = argparse.ArgumentParser()
p.add_argument('--members', required=True)
p.add_argument('--report')
a = p.parse_args()
source = pathlib.Path(a.members)
d = json.loads(source.read_text(encoding='utf-8'))
classes = d['classes']
wm = 'Lcom/android/server/wm/'
checks = []


def member(cls, name, descriptor, kind='methods'):
    original = cls
    while cls in classes:
        found = next((m for m in classes[cls][kind] if m['name'] == name
                      and m.get('descriptor', m.get('type')) == descriptor), None)
        if found:
            checks.append(dict(owner=original, declaring_class=cls, name=name, descriptor=descriptor, kind=kind))
            return
        cls = classes[cls]['superclass']
    raise AssertionError(f'Missing actual declaration: {original} {name} {descriptor}')


def m(owner, name, signature):
    member(wm+owner+';', name, signature)


for name, sig in [
    ('prepareSurfaces', '()V'), ('onConfigurationChanged', '(Landroid/content/res/Configuration;)V'),
    ('computeFreeformBounds', '(Landroid/graphics/Rect;Landroid/content/res/Configuration;)V'),
    ('setWindowingMode', '(I)V'), ('setBounds', '(Landroid/graphics/Rect;)I'),
    ('setAlwaysOnTop', '(Z)V'), ('isRootTask', '()Z'), ('isLeafTask', '()Z'),
    ('isAttached', '()Z'), ('getActivityType', '()I'), ('getWindowingMode', '()I'),
    ('isAlwaysOnTop', '()Z'), ('isOverrideBoundsAllowed', '()Z'), ('isOverrideWindowingModeAllowed', '()Z'),
    ('getBaseIntent', '()Landroid/content/Intent;'), ('getRelativeDisplayRotation', '()I'),
    ('getDisplayContent', '()Lcom/android/server/wm/DisplayContent;'),
    ('getDisplayArea', '()Lcom/android/server/wm/TaskDisplayArea;'),
    ('supportsFreeformInDisplayArea', '(Lcom/android/server/wm/TaskDisplayArea;)Z'),
    ('getBounds', '()Landroid/graphics/Rect;'), ('getRelativePosition', '(Landroid/graphics/Point;)V'),
    ('getPendingTransaction', '()Landroid/view/SurfaceControl$Transaction;'),
    ('getConfiguration', '()Landroid/content/res/Configuration;'),
    ('getRequestedOverrideConfiguration', '()Landroid/content/res/Configuration;'),
    ('onRequestedOverrideConfigurationChanged', '(Landroid/content/res/Configuration;)V'),
]:
    m('Task', name, sig)

for owner, name, sig in [
    ('WindowManagerService','systemReady','()V'), ('WindowManagerService','requestTraversal','()V'),
    ('RootWindowContainer','anyTaskForId','(II)Lcom/android/server/wm/Task;'),
    ('RootWindowContainer','getTopDisplayFocusedLeafTask','()Lcom/android/server/wm/Task;'),
    ('TaskDisplayArea','isValidWindowingMode','(ILcom/android/server/wm/ActivityRecord;Lcom/android/server/wm/Task;)Z'),
    ('DisplayContent','getStableRect','(Landroid/graphics/Rect;)V'),
    ('DisplayContent','getBounds','()Landroid/graphics/Rect;'),
    ('SurfaceAnimator','hasLeash','()Z'),
    ('TransitionController','inTransition','(Lcom/android/server/wm/WindowContainer;)Z'),
]:
    m(owner,name,sig)

for owner, name, ty in [
    ('WindowManagerService','mContext','Landroid/content/Context;'),
    ('WindowManagerService','mRoot',wm+'RootWindowContainer;'),
    ('WindowManagerService','mGlobalLock',wm+'WindowManagerGlobalLock;'),
    ('WindowManagerService','mAtmService',wm+'ActivityTaskManagerService;'),
    ('ActivityTaskManagerService','mSupportsMultiWindow','Z'),
    ('ActivityTaskManagerService','mSupportsFreeformWindowManagement','Z'),
    ('Task','mTaskId','I'), ('Task','mUserId','I'), ('Task','realActivity','Landroid/content/ComponentName;'),
    ('DisplayContent','mDisplayId','I'),
    ('Task','mSurfaceControl','Landroid/view/SurfaceControl;'),
    ('Task','mSurfaceAnimator',wm+'SurfaceAnimator;'), ('Task','mTransitionController',wm+'TransitionController;'),
]:
    member(wm+owner+';',name,ty,'fields')

member('Landroid/content/res/Configuration;', 'windowConfiguration', 'Landroid/app/WindowConfiguration;', 'fields')
for name, sig in [('getWindowingMode','()I'),('getBounds','()Landroid/graphics/Rect;'),('setAlwaysOnTop','(I)V')]:
    member('Landroid/app/WindowConfiguration;',name,sig)
member('Landroid/app/WindowConfiguration;','mAlwaysOnTop','I','fields')
for name, args in [('setScale','FF'),('setPosition','FF')]:
    member('Landroid/view/SurfaceControl$Transaction;',name,
           '(Landroid/view/SurfaceControl;'+args+')Landroid/view/SurfaceControl$Transaction;')


for name,sig in [('moveToFront','(Ljava/lang/String;)V'),('moveTaskToBack','(Lcom/android/server/wm/Task;)Z'),('setFocusable','(Z)Z'),('isFocusable','()Z'),('forAllTasks','(Ljava/util/function/Consumer;)V')]:
    m('Task',name,sig)
for name,sig in [('ensureActivitiesVisible','()V'),('resumeFocusedTasksTopActivities','()Z')]:
    m('RootWindowContainer',name,sig)
for name,sig in [('setForceTranslucent','(Z)Z'),('isForceTranslucent','()Z'),('isForceOpaque','()Z')]:
    m('Task',name,sig)
for name in ['deferWindowLayout','continueWindowLayout']:
    m('ActivityTaskManagerService',name,'()V')
member('Landroid/app/ActivityOptions;','setAvoidMoveToFront','()V')
member(wm+'Task;','mLastSurfaceSize','Landroid/graphics/Point;','fields')
member(wm+'Task;','mLastTimeMoved','J','fields')
member('Landroid/view/SurfaceControl$Transaction;','setWindowCrop','(Landroid/view/SurfaceControl;II)Landroid/view/SurfaceControl$Transaction;')
member('Landroid/view/SurfaceControl$Transaction;','setCornerRadius','(Landroid/view/SurfaceControl;F)Landroid/view/SurfaceControl$Transaction;')

for owner,name,sig in [
    ('RecentTasks','isVisibleRecentTask','(Lcom/android/server/wm/Task;)Z'),
    ('InsetsPolicy','updateSystemBars','(Lcom/android/server/wm/WindowState;IIZ)V'),
    ('DisplayContent','getDisplayPolicy','()Lcom/android/server/wm/DisplayPolicy;'),
    ('Task','getTopVisibleAppMainWindow','()Lcom/android/server/wm/WindowState;'),
    ('Task','isVisible','()Z'),
    ('WindowState','getTask','()Lcom/android/server/wm/Task;'),
    ('WindowState','isDrawn','()Z'),('WindowState','isVisible','()Z'),
    ('TaskChangeNotificationController','notifyTaskStackChanged','()V')]:
    m(owner,name,sig)
for owner,name,ty in [
    ('WindowContainer','mChildren','Ljava/util/ArrayList;'),
    ('WindowContainer','mLastLayer','I'),
    ('WindowContainer','mLastRelativeToLayer','Landroid/view/SurfaceControl;'),
    ('InsetsPolicy','mDisplayContent',wm+'DisplayContent;'),
    ('DisplayPolicy','mTopFullscreenOpaqueWindowState',wm+'WindowState;'),
    ('ActivityTaskManagerService','mTaskChangeNotificationController',wm+'TaskChangeNotificationController;')]:
    member(wm+owner+';',name,ty,'fields')
builder='Landroid/view/SurfaceControl$Builder;'
for name,sig in [('<init>','()V'),('setName','(Ljava/lang/String;)'+builder),
                 ('setParent','(Landroid/view/SurfaceControl;)'+builder),
                 ('setColorLayer','()'+builder),('setHidden','(Z)'+builder),
                 ('build','()Landroid/view/SurfaceControl;')]:
    member(builder,name,sig)
for name,args in [('setLayer','I'),('setRelativeLayer','Landroid/view/SurfaceControl;I'),
                  ('setColor','[F'),('setAlpha','F'),('show',''),('hide',''),('remove','')]:
    member('Landroid/view/SurfaceControl$Transaction;',name,
           '(Landroid/view/SurfaceControl;'+args+')Landroid/view/SurfaceControl$Transaction;')

for owner,name,sig in [('TransitionController','setNoAnimation','(Lcom/android/server/wm/WindowContainer;)V'),
    ('DisplayContent','getInsetsStateController','()Lcom/android/server/wm/InsetsStateController;'),
    ('InsetsStateController','getRawInsetsState','()Landroid/view/InsetsState;'),
    ('WindowState','getRequestedVisibleTypes','()I')]:m(owner,name,sig)
m('WindowState','canReceiveTouchInput','()Z')
member('Landroid/view/InsetsState;','calculateInsets','(Landroid/graphics/Rect;Landroid/graphics/Rect;IZ)Landroid/graphics/Insets;')
member(wm+'WindowState;','mAttrs','Landroid/view/WindowManager$LayoutParams;','fields')

for owner,name,sig in [
    ('Transition','collect','(Lcom/android/server/wm/WindowContainer;)V'),
    ('Transition','setNoAnimation','(Lcom/android/server/wm/WindowContainer;)V'),
    ('Task','moveTaskToBackInner','(Lcom/android/server/wm/Task;Lcom/android/server/wm/Transition;)V'),
    ('Task','updateSurfaceSize','(Landroid/view/SurfaceControl$Transaction;)V'),
    ('Task','isVisibleRequested','()Z'),
    ('TaskSnapshotController','recordSnapshot','(Lcom/android/server/wm/Task;)V'),
    ('WindowState','getFrame','()Landroid/graphics/Rect;')]:m(owner,name,sig)
member('Landroid/app/ActivityOptions;','setLaunchTaskId','(I)V')
member('Landroid/util/MergedConfiguration;','getMergedConfiguration','()Landroid/content/res/Configuration;')
member(wm+'WindowManagerService;','mTaskSnapshotController',wm+'TaskSnapshotController;','fields')
member(wm+'WindowState;','mLastReportedConfiguration','Landroid/util/MergedConfiguration;','fields')


m('Transition','addFlag','(I)V')
m('Transition','getFlags','()I')
m('TransitionController','requestStartTransition','(Lcom/android/server/wm/Transition;Lcom/android/server/wm/Task;Landroid/window/RemoteTransition;Ljava/util/List;)Lcom/android/server/wm/Transition;')
member(wm+'Transition;','mType','I','fields')
member('Landroid/view/WindowManager;','TRANSIT_FLAG_INVISIBLE','I','fields')

result = dict(status='PASS', count=len(checks), inventory_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
              artifacts=d['artifacts'], checks=checks,
              limitation='Offline declarations only; no Android runtime, no hook or recovery execution.')
if a.report:
    pathlib.Path(a.report).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS target declarations:',len(checks),'exact members including inherited declarations')
