import argparse
import pathlib
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--jdk', default=r'C:\Program Files\Android\Android Studio\jbr')
p.add_argument('--out', required=True)
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
jdk = pathlib.Path(a.jdk)
out = pathlib.Path(a.out).resolve()
out.mkdir(parents=True, exist_ok=True)
subprocess.run([str(jdk/'bin/javac.exe'), '-encoding', 'UTF-8', '--release', '17', '-d', str(out),
    str(root/'src/dev/local/sunwindowdemo/Geometry.java'), str(root/'tests/GeometryCheck.java')], check=True)
subprocess.run([str(jdk/'bin/java.exe'), '-cp', str(out), 'dev.local.sunwindowdemo.GeometryCheck'], check=True)
