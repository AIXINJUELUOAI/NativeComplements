import pathlib,subprocess,argparse
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=True)
jdk=pathlib.Path(r'C:\Program Files\Android\Android Studio\jbr\bin')
names=['Geometry','GestureMath','Rules','GestureGate','MotionStyle','BackSwipe','WindowHistory']
files=[root/'src/dev/local/sunwindowdemo'/(n+'.java') for n in names]
files += [root/'tests'/(n+'.java') for n in ['GeometryCheck','StateChecks','GestureGateChecks','GeometryChecks','MotionChecks','DropChecks','HistoryChecks']]
subprocess.run([str(jdk/'javac.exe'),'--release','17','-encoding','UTF-8','-d',str(out),*map(str,files)],check=True)
for n in ['GeometryCheck','StateChecks','GestureGateChecks','GeometryChecks','MotionChecks','DropChecks','HistoryChecks']:
    subprocess.run([str(jdk/'java.exe'),'-cp',str(out),'dev.local.sunwindowdemo.'+n],check=True)
