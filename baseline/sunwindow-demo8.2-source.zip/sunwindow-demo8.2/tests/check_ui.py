"""Exact declaration checks against the saved device APKs, not runtime verification."""
import argparse,json,pathlib,hashlib
p=argparse.ArgumentParser();p.add_argument('--members',required=True);p.add_argument('--report',required=True);a=p.parse_args()
source=pathlib.Path(a.members);d=json.loads(source.read_text(encoding='utf-8'));classes=d['classes'];checks=[]
def member(owner,name,desc,kind='methods'):
    cls=owner
    while cls in classes:
        if any(x['name']==name and x.get('descriptor',x.get('type'))==desc for x in classes[cls][kind]):
            checks.append(dict(owner=owner,declaring_class=cls,name=name,descriptor=desc,kind=kind));return
        cls=classes[cls]['superclass']
    raise AssertionError((owner,name,desc))
sys='Lcom/android/systemui/';qs='Lcom/android/quickstep/';group='Lcom/android/wm/shell/shared/GroupedTaskInfo;'
panel=sys+'navigationbar/gestural/BackPanelController;'
for name,sig in [('onMotionEvent','(Landroid/view/MotionEvent;)V'),('onViewAttached','()V'),('onDestroy','()V')]:member(panel,name,sig)
member(panel,'mView','Landroid/view/View;','fields')
member(panel,'backCallback',sys+'plugins/NavigationEdgeBackPlugin$BackCallback;','fields')
member(sys+'plugins/NavigationEdgeBackPlugin$BackCallback;','cancelBack','()V')
edge=sys+'navigationbar/gestural/EdgeBackGestureHandler;'
controller='Lcom/android/wm/shell/back/BackAnimationController;'
impl='Lcom/android/wm/shell/back/BackAnimationController$BackAnimationImpl;'
member(sys+'navigationbar/gestural/EdgeBackGestureHandler$5;','this$0',edge,'fields')
member(edge,'mBackAnimation',impl,'fields');member(impl,'this$0',controller,'fields')
for name,ty in [('mBackNavigationInfo','Landroid/window/BackNavigationInfo;'),('mPostCommitAnimationInProgress','Z'),('mShellExecutor','Lcom/android/wm/shell/common/ShellExecutor;')]:member(controller,name,ty,'fields')
rv=qs+'views/RecentsView;'
for name,sig in [('applyLoadPlan','(Ljava/util/List;I)V'),('shouldAvoidAddingStubTaskView','('+group+')Z'),('reloadIfNeeded','()V')]:member(rv,name,sig)
member(rv,'mAppliedTaskListChangeId','I','fields')
for name,sig in [('containsTask','(I)Z'),('getTasks','()Ljava/util/List;')]:member(qs+'util/GroupTask;',name,sig)
member(group,'getTaskInfo1','()Landroid/app/TaskInfo;');member(group,'isBaseType','(I)Z')
member(qs+'TouchInteractionHandler;','onInputEvent','(Landroid/view/InputEvent;)V')
for name in ['onCreate','onDestroy']:member(qs+'TouchInteractionService;',name,'()V')
shot=sys+'screenshot/ScreenshotController;';window=sys+'screenshot/ScreenshotWindow;'
member(shot,'handleScreenshot','('+sys+'screenshot/ScreenshotData;'+sys+'screenshot/TakeScreenshotExecutorImpl$sam$java_util_function_Consumer$0;'+sys+'screenshot/TakeScreenshotService$RequestCallbackImpl;)V')
member(window,'removeWindow','()V');member(shot,'window',window,'fields');member(window,'window','Lcom/android/internal/policy/PhoneWindow;','fields')
pathlib.Path(a.report).write_text(json.dumps(dict(status='PASS',count=len(checks),checks=checks,artifacts=d['artifacts'],inventory_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),limitation='Saved APK member declarations; no phone gesture executed'),indent=2),encoding='utf-8')
print('PASS Demo7 UI declarations:',len(checks))
